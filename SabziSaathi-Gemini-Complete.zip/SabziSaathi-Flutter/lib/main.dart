import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  runApp(const SabziSaathiApp());
}

const forest = Color(0xFF2F6B4F);
const deepGreen = Color(0xFF214B38);
const cream = Color(0xFFF7F7F0);
const sage = Color(0xFFE4EDE1);
const ink = Color(0xFF26372D);
const muted = Color(0xFF737D75);

class SabziSaathiApp extends StatelessWidget {
  const SabziSaathiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: forest, brightness: Brightness.light,
      surface: const Color(0xFFFCFCF8));
    return MaterialApp(
      title: 'SabziSaathi', debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: cream,
        textTheme: const TextTheme(
          headlineMedium: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: ink, letterSpacing: -0.7),
          titleLarge: TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: ink),
          titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: ink),
          bodyLarge: TextStyle(fontSize: 16, color: ink, height: 1.35),
          bodyMedium: TextStyle(fontSize: 14, color: ink, height: 1.35),
          bodySmall: TextStyle(fontSize: 12, color: muted),
        ),
        appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, elevation: 0, centerTitle: false),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15)),
        cardTheme: CardThemeData(color: Colors.white, elevation: 0.5, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      ),
      home: const MainShell(),
    );
  }
}

class Vegetable {
  const Vegetable(this.name, this.hindi, this.category, this.icon, this.unit);
  final String name, hindi, category, unit;
  final IconData icon;
}

const vegetables = <Vegetable>[
  Vegetable('Potato', 'Aloo', 'Everyday', Icons.circle, 'kg'),
  Vegetable('Onion', 'Pyaz', 'Everyday', Icons.layers, 'kg'),
  Vegetable('Tomato', 'Tamatar', 'Everyday', Icons.local_florist, 'kg'),
  Vegetable('Garlic', 'Lehsun', 'Everyday', Icons.grain, 'g'),
  Vegetable('Ginger', 'Adrak', 'Everyday', Icons.spa, 'g'),
  Vegetable('Green chilli', 'Hari mirch', 'Everyday', Icons.eco, 'g'),
  Vegetable('Capsicum', 'Shimla mirch', 'Everyday', Icons.circle_outlined, 'pcs'),
  Vegetable('Cucumber', 'Kheera', 'Everyday', Icons.water_drop, 'pcs'),
  Vegetable('Carrot', 'Gajar', 'Everyday', Icons.grass, 'kg'),
  Vegetable('Radish', 'Mooli', 'Everyday', Icons.grass, 'pcs'),
  Vegetable('Beetroot', 'Chukandar', 'Everyday', Icons.circle, 'pcs'),
  Vegetable('Bottle gourd', 'Lauki', 'Gourds', Icons.energy_savings_leaf, 'pcs'),
  Vegetable('Ridge gourd', 'Tori', 'Gourds', Icons.eco, 'pcs'),
  Vegetable('Sponge gourd', 'Gilki', 'Gourds', Icons.eco, 'pcs'),
  Vegetable('Bitter gourd', 'Karela', 'Gourds', Icons.eco, 'pcs'),
  Vegetable('Pumpkin', 'Kaddu', 'Gourds', Icons.circle, 'kg'),
  Vegetable('Ash gourd', 'Petha', 'Gourds', Icons.circle_outlined, 'pcs'),
  Vegetable('Round gourd', 'Tinda', 'Gourds', Icons.circle, 'pcs'),
  Vegetable('Pointed gourd', 'Parwal', 'Gourds', Icons.eco, 'pcs'),
  Vegetable('Ivy gourd', 'Kundru', 'Gourds', Icons.eco, 'g'),
  Vegetable('Spinach', 'Palak', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Fenugreek leaves', 'Methi', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Mustard greens', 'Sarson', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Bathua', 'Bathua', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Amaranth', 'Chaulai', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Coriander', 'Dhaniya', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Mint', 'Pudina', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Curry leaves', 'Kadi patta', 'Leafy greens', Icons.grass, 'bunch'),
  Vegetable('Cauliflower', 'Phool gobhi', 'Cruciferous', Icons.filter_vintage, 'pcs'),
  Vegetable('Cabbage', 'Patta gobhi', 'Cruciferous', Icons.filter_vintage, 'pcs'),
  Vegetable('Broccoli', 'Broccoli', 'Cruciferous', Icons.grass, 'pcs'),
  Vegetable('Green peas', 'Matar', 'Beans & peas', Icons.grain, 'kg'),
  Vegetable('French beans', 'Beans', 'Beans & peas', Icons.grass, 'g'),
  Vegetable('Cluster beans', 'Gawar phali', 'Beans & peas', Icons.grass, 'g'),
  Vegetable('Broad beans', 'Sem', 'Beans & peas', Icons.grass, 'g'),
  Vegetable('Green chickpeas', 'Hara chana', 'Beans & peas', Icons.grain, 'g'),
  Vegetable('Colocasia', 'Arbi', 'Roots & tubers', Icons.circle, 'kg'),
  Vegetable('Elephant foot yam', 'Suran', 'Roots & tubers', Icons.circle, 'kg'),
  Vegetable('Sweet potato', 'Shakarkandi', 'Roots & tubers', Icons.circle, 'kg'),
  Vegetable('Lotus root', 'Kamal kakdi', 'Roots & tubers', Icons.circle, 'pcs'),
  Vegetable('Drumstick', 'Sahjan', 'Regional', Icons.grass, 'pcs'),
  Vegetable('Raw banana', 'Kachcha kela', 'Regional', Icons.eco, 'pcs'),
  Vegetable('Jackfruit', 'Kathal', 'Regional', Icons.circle, 'kg'),
  Vegetable('Raw papaya', 'Kachcha papita', 'Regional', Icons.circle, 'pcs'),
  Vegetable('Chayote', 'Chow chow', 'Regional', Icons.eco, 'pcs'),
  Vegetable('Mushroom', 'Khumb', 'Specialty', Icons.grain, 'g'),
  Vegetable('Sweet corn', 'Makka', 'Specialty', Icons.grain, 'pcs'),
  Vegetable('Baby corn', 'Baby corn', 'Specialty', Icons.grain, 'pcs'),
  Vegetable('Zucchini', 'Zucchini', 'Specialty', Icons.eco, 'pcs'),
  Vegetable('Celery', 'Celery', 'Specialty', Icons.grass, 'bunch'),
  Vegetable('Lemon', 'Nimbu', 'Everyday', Icons.circle, 'pcs'),
  Vegetable('Raw mango', 'Kachcha aam', 'Seasonal', Icons.eco, 'pcs'),
  Vegetable('Water chestnut', 'Singhara', 'Seasonal', Icons.circle, 'kg'),
];

class InventoryItem {
  InventoryItem({this.id, required this.name, required this.hindi, required this.quantity,
    required this.unit, required this.purchaseDate, required this.location, required this.condition});
  final int? id;
  final String name, hindi, unit, location, condition;
  final double quantity;
  final String purchaseDate;
  factory InventoryItem.fromMap(Map<String, Object?> m) => InventoryItem(
    id: m['id'] as int, name: m['name'] as String, hindi: m['hindi'] as String,
    quantity: (m['quantity'] as num).toDouble(), unit: m['unit'] as String,
    purchaseDate: m['purchase_date'] as String, location: m['location'] as String,
    condition: m['condition'] as String);
  Map<String, Object?> toMap() => {'name': name, 'hindi': hindi, 'quantity': quantity,
    'unit': unit, 'purchase_date': purchaseDate, 'location': location, 'condition': condition};
}

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'sabzisaathi.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE inventory(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, hindi TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, purchase_date TEXT NOT NULL, location TEXT NOT NULL, condition TEXT NOT NULL)''');
      });
    return _db!;
  }
  Future<List<InventoryItem>> all() async {
    final rows = await (await database).query('inventory', orderBy: 'purchase_date ASC');
    return rows.map(InventoryItem.fromMap).toList();
  }
  Future<void> add(InventoryItem item) async => (await database).insert('inventory', item.toMap());
  Future<void> delete(int id) async => (await database).delete('inventory', where: 'id = ?', whereArgs: [id]);
  Future<void> update(InventoryItem item) async => (await database).update('inventory', item.toMap(), where: 'id = ?', whereArgs: [item.id]);
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  List<InventoryItem> items = [];
  bool loading = true;
  @override void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final data = await AppDatabase.instance.all();
    if (mounted) setState(() { items = data; loading = false; });
  }
  Future<void> addItem() async {
    final result = await showModalBottomSheet<bool>(context: context, isScrollControlled: true,
      backgroundColor: Colors.transparent, builder: (_) => AddVegetableSheet(onSave: (item) async { await AppDatabase.instance.add(item); }));
    if (result == true) refresh();
  }
  @override Widget build(BuildContext context) {
    final pages = [HomePage(items: items, onAdd: addItem, onOpenFridge: () => setState(() => index = 1), onOpenAi: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GeminiAssistantPage(items: items)))),
      FridgePage(items: items, onAdd: addItem, onDelete: (id) async { await AppDatabase.instance.delete(id); refresh(); }),
      const SettingsPage()];
    return Scaffold(body: SafeArea(child: loading ? const Center(child: CircularProgressIndicator()) : pages[index]),
      bottomNavigationBar: NavigationBar(height: 70, selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v),
        backgroundColor: Colors.white, indicatorColor: sage,
        destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.kitchen_outlined), selectedIcon: Icon(Icons.kitchen), label: 'My Fridge'),
          NavigationDestination(icon: Icon(Icons.tune_outlined), selectedIcon: Icon(Icons.tune), label: 'Settings')]),
      floatingActionButton: index == 1 ? FloatingActionButton.extended(onPressed: addItem, backgroundColor: forest,
        foregroundColor: Colors.white, icon: const Icon(Icons.add), label: const Text('Add vegetable')) : null);
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.items, required this.onAdd, required this.onOpenFridge, required this.onOpenAi});
  final List<InventoryItem> items; final VoidCallback onAdd, onOpenFridge, onOpenAi;
  @override Widget build(BuildContext context) {
    final attention = items.where((e) => e.condition != 'Fresh').toList();
    final hour = DateTime.now().hour;
    final greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
    return CustomScrollView(slivers: [
      SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 24), sliver: SliverList(delegate: SliverChildListDelegate([
        Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('SABZISAATHI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2, color: forest)), const SizedBox(height: 9), Text('$greeting 👋', style: Theme.of(context).textTheme.headlineMedium), const SizedBox(height: 4), const Text('A little care keeps your kitchen fresh.', style: TextStyle(color: muted))])),
          CircleAvatar(radius: 23, backgroundColor: sage, child: const Icon(Icons.eco, color: forest))]),
        const SizedBox(height: 24),
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: deepGreen, borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('YOUR KITCHEN TODAY', style: TextStyle(color: Color(0xFFBFD5C5), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
          const SizedBox(height: 13), Row(children: [Expanded(child: _metric('${items.length}', 'Items at home', Colors.white)), Container(width: 1, height: 43, color: Colors.white24), Expanded(child: _metric('${attention.length}', 'Need a check', const Color(0xFFFFD69A)))]),
          const SizedBox(height: 18), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: onOpenFridge, icon: const Icon(Icons.arrow_forward, size: 17), label: const Text('View my fridge'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54), padding: const EdgeInsets.symmetric(vertical: 13))))
        ])),
        const SizedBox(height: 25),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Aaj kya banayein?', style: Theme.of(context).textTheme.titleLarge), const Text('MEAL IDEAS', style: TextStyle(fontSize: 10, color: muted, fontWeight: FontWeight.w800, letterSpacing: 1))]),
        const SizedBox(height: 12), RecipeCard(items: items),
        const SizedBox(height: 14),
        InkWell(onTap: onOpenAi, borderRadius: BorderRadius.circular(21), child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(21), border: Border.all(color: const Color(0xFFDCE7DC))),
          child: Row(children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: sage, borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.auto_awesome, color: forest, size: 25)),
            const SizedBox(width: 13),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Ask SabziSaathi AI', style: TextStyle(fontWeight: FontWeight.w800, color: ink, fontSize: 16)),
              SizedBox(height: 3), Text('Recipes, freshness guidance and meal plans', style: TextStyle(color: muted, fontSize: 12))
            ])),
            const Icon(Icons.arrow_forward_ios, size: 15, color: forest)
          ]),
        )),
        const SizedBox(height: 25),
        Text('Make it easy', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 12),
        Row(children: [Expanded(child: _quickAction(context, Icons.add_circle_outline, 'Add vegetables', 'Update your fridge', forest, onAdd)), const SizedBox(width: 12), Expanded(child: _quickAction(context, Icons.kitchen_outlined, 'My fridge', 'See what you have', const Color(0xFFB77943), onOpenFridge))]),
        const SizedBox(height: 25),
        if (attention.isNotEmpty) ...[Text('Worth checking', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 10), ...attention.take(2).map((e) => _attentionTile(context, e))]
        else Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: sage.withValues(alpha: .65), borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.check_circle_outline, color: forest), SizedBox(width: 10), Expanded(child: Text('Everything looks good. Add your vegetables to get started.', style: TextStyle(color: ink)))])),
        const SizedBox(height: 30), const Text('Small steps. Less waste. Fresher meals.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
      ])))
    ]);
  }
  Widget _metric(String value, String label, Color color) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: TextStyle(color: color, fontSize: 29, fontWeight: FontWeight.w800)), const SizedBox(height: 2), Text(label, style: const TextStyle(color: Color(0xFFD8E5DB), fontSize: 12))]);
  Widget _quickAction(BuildContext context, IconData icon, String title, String subtitle, Color color, VoidCallback tap) => InkWell(onTap: tap, borderRadius: BorderRadius.circular(19), child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFE9EDE7))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: color, size: 25), const SizedBox(height: 12), Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: ink)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: muted, fontSize: 12))])));
  Widget _attentionTile(BuildContext context, InventoryItem item) => Card(child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFFFF1DF), child: Icon(Icons.visibility_outlined, color: Color(0xFFB77943))), title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${item.condition} • ${item.location}'), trailing: const Icon(Icons.chevron_right)));
}

class RecipeCard extends StatelessWidget {
  const RecipeCard({super.key, required this.items});
  final List<InventoryItem> items;
  @override Widget build(BuildContext context) {
    final names = items.map((e) => e.name.toLowerCase()).toList();
    final idea = names.any((n) => n.contains('potato')) && names.any((n) => n.contains('tomato')) ? 'Aloo Tamatar' : names.any((n) => n.contains('spinach')) ? 'Palak wali dal' : names.any((n) => n.contains('cauliflower')) ? 'Gobi masala' : 'Seasonal vegetable sabzi';
    return Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: const Color(0xFFEAF0E5), borderRadius: BorderRadius.circular(21)), child: Row(children: [Container(width: 58, height: 58, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)), child: const Icon(Icons.restaurant_menu, color: forest, size: 29)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('A simple idea from your kitchen', style: TextStyle(color: muted, fontSize: 12)), const SizedBox(height: 4), Text(idea, style: const TextStyle(color: ink, fontSize: 17, fontWeight: FontWeight.w800)), const Text('Based on items in your fridge', style: TextStyle(color: muted, fontSize: 12))])), const Icon(Icons.arrow_forward_ios, size: 15, color: forest)]));
  }
}

class FridgePage extends StatefulWidget {
  const FridgePage({super.key, required this.items, required this.onAdd, required this.onDelete});
  final List<InventoryItem> items; final VoidCallback onAdd; final ValueChanged<int> onDelete;
  @override State<FridgePage> createState() => _FridgePageState();
}
class _FridgePageState extends State<FridgePage> {
  String query = '';
  @override Widget build(BuildContext context) {
    final filtered = widget.items.where((e) => '${e.name} ${e.hindi}'.toLowerCase().contains(query.toLowerCase())).toList();
    return Column(children: [Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('My Fridge', style: Theme.of(context).textTheme.headlineMedium), const SizedBox(height: 5), Text('${widget.items.length} items saved on this phone', style: const TextStyle(color: muted)), const SizedBox(height: 17), TextField(onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search vegetables'))])),
      Expanded(child: filtered.isEmpty ? _empty(context) : ListView.separated(padding: const EdgeInsets.fromLTRB(20, 6, 20, 20), itemCount: filtered.length, separatorBuilder: (_, __) => const SizedBox(height: 9), itemBuilder: (context, i) { final item = filtered[i]; return Card(child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 7), leading: _produceIcon(item.name), title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${item.hindi} • ${item.location}\n${item.condition} • Bought ${item.purchaseDate}'), isThreeLine: true, trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('${item.quantity.toStringAsFixed(item.quantity % 1 == 0 ? 0 : 1)} ${item.unit}', style: const TextStyle(fontWeight: FontWeight.w800, color: forest)), PopupMenuButton<String>(onSelected: (v) { if (v == 'delete' && item.id != null) widget.onDelete(item.id!); }, itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Remove item'))])]))); })),
    ]);
  }
  Widget _empty(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(width: 86, height: 86, decoration: const BoxDecoration(color: sage, shape: BoxShape.circle), child: const Icon(Icons.kitchen_outlined, size: 40, color: forest)), const SizedBox(height: 18), Text(query.isEmpty ? 'Your fridge is waiting' : 'No vegetables found', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 7), Text(query.isEmpty ? 'Add the vegetables you have at home. They will stay saved on this phone.' : 'Try another name or Hindi spelling.', textAlign: TextAlign.center, style: const TextStyle(color: muted)), const SizedBox(height: 18), FilledButton.icon(onPressed: widget.onAdd, icon: const Icon(Icons.add), label: const Text('Add vegetables'))])));
}

Widget _produceIcon(String name) {
  final n = name.toLowerCase();
  final color = n.contains('tomato') || n.contains('beet') ? const Color(0xFFD96A4F) : n.contains('spinach') || n.contains('coriander') || n.contains('peas') ? forest : n.contains('carrot') || n.contains('pumpkin') ? const Color(0xFFD98A57) : const Color(0xFFB7A27C);
  return CircleAvatar(backgroundColor: color.withValues(alpha: .13), child: Icon(Icons.spa_outlined, color: color));
}

class AddVegetableSheet extends StatefulWidget {
  const AddVegetableSheet({super.key, required this.onSave});
  final Future<void> Function(InventoryItem) onSave;
  @override State<AddVegetableSheet> createState() => _AddVegetableSheetState();
}
class _AddVegetableSheetState extends State<AddVegetableSheet> {
  final search = TextEditingController();
  final quantity = TextEditingController(text: '1');
  Vegetable? selected;
  String location = 'Refrigerator';
  String condition = 'Fresh';
  String unit = 'kg';
  DateTime purchaseDate = DateTime.now();
  bool saving = false;
  @override void dispose() { search.dispose(); quantity.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final matches = vegetables.where((v) => '${v.name} ${v.hindi} ${v.category}'.toLowerCase().contains(search.text.toLowerCase())).toList();
    return Container(height: MediaQuery.of(context).size.height * .88, padding: EdgeInsets.fromLTRB(20, 12, 20, MediaQuery.of(context).viewInsets.bottom + 20), decoration: const BoxDecoration(color: cream, borderRadius: BorderRadius.vertical(top: Radius.circular(26))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(5)))), const SizedBox(height: 17), Text(selected == null ? 'Add vegetables' : 'Add ${selected!.name}', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 12),
      if (selected == null) ...[TextField(controller: search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search English or Hindi name')), const SizedBox(height: 10), Expanded(child: ListView.builder(itemCount: matches.length, itemBuilder: (_, i) { final v = matches[i]; return ListTile(onTap: () => setState(() { selected = v; unit = v.unit; }), leading: _produceIcon(v.name), title: Text(v.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${v.hindi} • ${v.category}'), trailing: const Icon(Icons.add_circle_outline, color: forest)); }))]
      else ...[Text('${selected!.hindi} • ${selected!.category}', style: const TextStyle(color: muted)), const SizedBox(height: 16), Row(children: [Expanded(child: TextField(controller: quantity, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Quantity'))), const SizedBox(width: 10), Expanded(child: DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'Unit'), items: ['kg','g','pcs','bunch','pack'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => unit = v ?? unit)))]), const SizedBox(height: 12), DropdownButtonFormField<String>(value: location, decoration: const InputDecoration(labelText: 'Where are you storing it?'), items: ['Refrigerator','Pantry','Countertop','Freezer'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => location = v ?? location)), const SizedBox(height: 12), DropdownButtonFormField<String>(value: condition, decoration: const InputDecoration(labelText: 'Observed condition'), items: ['Fresh','Beginning to wilt or soften','Needs inspection','Suspected spoilage'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => condition = v ?? condition)), const SizedBox(height: 12), OutlinedButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: purchaseDate, firstDate: DateTime(2020), lastDate: DateTime.now()); if (d != null) setState(() => purchaseDate = d); }, icon: const Icon(Icons.calendar_today), label: Text('Purchase date: ${purchaseDate.day}/${purchaseDate.month}/${purchaseDate.year}')), const Spacer(), Row(children: [TextButton(onPressed: () => setState(() => selected = null), child: const Text('Choose another')), const Spacer(), FilledButton(onPressed: saving ? null : _save, child: Text(saving ? 'Saving…' : 'Save to fridge'))])]
    ]));
  }
  Future<void> _save() async {
    final q = double.tryParse(quantity.text.trim());
    if (q == null || q <= 0 || selected == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid quantity.'))); return; }
    setState(() => saving = true);
    final d = '${purchaseDate.year.toString().padLeft(4,'0')}-${purchaseDate.month.toString().padLeft(2,'0')}-${purchaseDate.day.toString().padLeft(2,'0')}';
    await widget.onSave(InventoryItem(name: selected!.name, hindi: selected!.hindi, quantity: q, unit: unit, purchaseDate: d, location: location, condition: condition));
    if (mounted) Navigator.pop(context, true);
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 22, 20, 30), children: [Text('Settings', style: Theme.of(context).textTheme.headlineMedium), const SizedBox(height: 6), const Text('Make SabziSaathi feel right for your home.', style: TextStyle(color: muted)), const SizedBox(height: 22), _setting(Icons.language, 'Language', 'English (Hindi support planned)'), _setting(Icons.notifications_outlined, 'Reminders', 'Notification scheduling not enabled yet'), _setting(Icons.cloud_off_outlined, 'Offline storage', 'Your inventory is stored locally on this phone'), _setting(Icons.auto_awesome_outlined, 'Gemini assistant', const String.fromEnvironment('GEMINI_API_KEY').isEmpty ? 'API key not configured' : 'API key supplied at build time'), _setting(Icons.privacy_tip_outlined, 'Privacy', 'No account or cloud inventory sync'), const SizedBox(height: 20), const Text('SabziSaathi • Early functional build', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12))]);
  Widget _setting(IconData icon, String title, String subtitle) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: CircleAvatar(backgroundColor: sage, child: Icon(icon, color: forest)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right)));
}

class GeminiService {
  GeminiService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  static const _key = String.fromEnvironment('GEMINI_API_KEY');
  static const _model = String.fromEnvironment('GEMINI_MODEL', defaultValue: 'gemini-2.5-flash');
  bool get isConfigured => _key.isNotEmpty;

  Future<String> generate(String prompt) async {
    if (_key.isEmpty) throw Exception('Gemini is not configured. Build with --dart-define=GEMINI_API_KEY=YOUR_KEY. The offline app remains available.');
    final uri = Uri.https('generativelanguage.googleapis.com', '/v1beta/models/$_model:generateContent', {'key': _key});
    final response = await _client.post(uri, headers: {'Content-Type': 'application/json'}, body: jsonEncode({
      'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
      'generationConfig': {'temperature': 0.55, 'maxOutputTokens': 1400}
    })).timeout(const Duration(seconds: 35));
    if (response.statusCode != 200) {
      String detail = 'HTTP ${response.statusCode}';
      try { final error = jsonDecode(response.body) as Map<String, dynamic>; detail = error['error']?['message']?.toString() ?? detail; } catch (_) {}
      throw Exception('Gemini request failed: $detail');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = data['candidates'] as List<dynamic>?;
    if (candidates == null || candidates.isEmpty) throw Exception('Gemini did not return an answer. Please try again.');
    final content = candidates.first['content'] as Map<String, dynamic>?;
    final parts = content?['parts'] as List<dynamic>?;
    final answer = parts?.whereType<Map<String, dynamic>>().map((part) => part['text']).whereType<String>().join('\n').trim();
    if (answer == null || answer.isEmpty) throw Exception('Gemini returned an empty answer.');
    return answer;
  }

  Future<String> suggestRecipe(List<InventoryItem> items, {String preference = ''}) {
    final inventory = items.map((e) => '${e.name} (${e.hindi}), ${e.quantity} ${e.unit}, condition: ${e.condition}, storage: ${e.location}').join('; ');
    return generate("""
You are SabziSaathi, a practical Indian home-cooking assistant.
Suggest 2 realistic Indian household recipes based primarily on this inventory:
${inventory.isEmpty ? 'No vegetables have been saved yet.' : inventory}
User preference: ${preference.isEmpty ? 'No extra preference.' : preference}
For each recipe include name, why it fits, ingredients grouped into 'from my fridge' and 'pantry staples to add', approximate preparation time, numbered cooking steps, and one food-safety note where relevant. Do not claim ingredients are available unless listed. Keep instructions beginner-friendly and include Hindi dish names where natural.
""");
  }

  Future<String> assessFreshness(InventoryItem item, String observations) => generate("""
You are a cautious food-storage information assistant for an Indian household.
Item: ${item.name} (${item.hindi})
Purchase date: ${item.purchaseDate}
Storage location: ${item.location}
User-recorded condition: ${item.condition}
Additional visible/smell/texture observations: ${observations.isEmpty ? 'Not provided.' : observations}
Give: (1) signs to inspect, (2) storage considerations, (3) practical next step. Do NOT diagnose safety from dates alone or guarantee food is safe. If there is mould, slime, leaking, unusual odour, or uncertainty, advise discarding rather than tasting. Do not invent a precise expiry date.
""");

  Future<String> createMealPlan(List<InventoryItem> items, String householdSize) {
    final inventory = items.map((e) => '${e.name} (${e.hindi}), ${e.quantity} ${e.unit}, condition: ${e.condition}').join('; ');
    return generate("""
Create a practical 3-day Indian household meal plan for $householdSize.
Available vegetable inventory: ${inventory.isEmpty ? 'Inventory is empty; suggest a small starter shopping list.' : inventory}
Prioritize using items marked other than Fresh earlier, without assuming they are unsafe. Include lunch and dinner, ingredients to buy, efficient ingredient reuse, and a compact shopping list. Keep recipes realistic. Do not assume unavailable items are already present.
""");
  }
}

class GeminiAssistantPage extends StatefulWidget {
  const GeminiAssistantPage({super.key, required this.items});
  final List<InventoryItem> items;
  @override State<GeminiAssistantPage> createState() => _GeminiAssistantPageState();
}

class _GeminiAssistantPageState extends State<GeminiAssistantPage> {
  final GeminiService _gemini = GeminiService();
  final TextEditingController _preference = TextEditingController();
  final TextEditingController _observations = TextEditingController();
  String _mode = 'Recipes';
  String _householdSize = '3–4 people';
  InventoryItem? _selectedItem;
  String? _answer, _error;
  bool _busy = false;

  @override void initState() { super.initState(); if (widget.items.isNotEmpty) _selectedItem = widget.items.first; }
  @override void dispose() { _preference.dispose(); _observations.dispose(); super.dispose(); }

  Future<void> _ask() async {
    setState(() { _busy = true; _answer = null; _error = null; });
    try {
      late final String result;
      if (_mode == 'Recipes') {
        result = await _gemini.suggestRecipe(widget.items, preference: _preference.text.trim());
      } else if (_mode == 'Freshness') {
        if (_selectedItem == null) throw Exception('Add a vegetable to My Fridge first.');
        result = await _gemini.assessFreshness(_selectedItem!, _observations.text.trim());
      } else {
        result = await _gemini.createMealPlan(widget.items, _householdSize);
      }
      if (mounted) setState(() => _answer = result);
    } catch (e) { if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  @override Widget build(BuildContext context) {
    final configured = _gemini.isConfigured;
    return Scaffold(appBar: AppBar(title: const Text('SabziSaathi AI')), body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), children: [
      Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: deepGreen, borderRadius: BorderRadius.circular(21)), child: Row(children: [
        const Icon(Icons.auto_awesome, color: Color(0xFFFFD69A), size: 28), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Your kitchen, with a little AI help', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 4),
          Text(configured ? 'Gemini is configured for online assistance.' : 'Gemini key not configured. Add it when building the app.', style: const TextStyle(color: Color(0xFFD8E5DB), fontSize: 12))
        ]))
      ])),
      const SizedBox(height: 20),
      SegmentedButton<String>(segments: const [ButtonSegment(value: 'Recipes', label: Text('Recipes'), icon: Icon(Icons.restaurant_menu)), ButtonSegment(value: 'Freshness', label: Text('Freshness'), icon: Icon(Icons.spa_outlined)), ButtonSegment(value: 'Meal plan', label: Text('Meal plan'), icon: Icon(Icons.calendar_month_outlined))], selected: {_mode}, onSelectionChanged: (v) => setState(() { _mode = v.first; _answer = null; _error = null; }), showSelectedIcon: false),
      const SizedBox(height: 18),
      if (_mode == 'Recipes') ...[
        Text('Cook with what you have', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 5),
        Text('${widget.items.length} items from My Fridge will be sent to Gemini. Your local inventory stays on this phone.', style: const TextStyle(color: muted)), const SizedBox(height: 14),
        TextField(controller: _preference, decoration: const InputDecoration(labelText: 'Any preference? (optional)', hintText: 'e.g. less spicy, quick dinner, no onion')),
      ] else if (_mode == 'Freshness') ...[
        Text('Inspect a vegetable', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 5),
        const Text('Gemini gives inspection guidance, not a safety certification or expiry guarantee.', style: TextStyle(color: muted)), const SizedBox(height: 14),
        if (widget.items.isEmpty) const Text('Your My Fridge list is empty. Add a vegetable first.') else DropdownButtonFormField<InventoryItem>(value: _selectedItem, isExpanded: true, decoration: const InputDecoration(labelText: 'Choose from My Fridge'), items: widget.items.map((item) => DropdownMenuItem(value: item, child: Text('${item.name} • ${item.hindi}'))).toList(), onChanged: (v) => setState(() { _selectedItem = v; _answer = null; })),
        const SizedBox(height: 12), TextField(controller: _observations, maxLines: 3, decoration: const InputDecoration(labelText: 'What do you notice? (optional)', hintText: 'e.g. soft spots, smell, slimy surface, colour change')),
      ] else ...[
        Text('Plan the next three days', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 5), const Text('The plan uses your saved vegetables and identifies items to buy.', style: TextStyle(color: muted)), const SizedBox(height: 14),
        DropdownButtonFormField<String>(value: _householdSize, decoration: const InputDecoration(labelText: 'Household size'), items: const ['1–2 people', '3–4 people', '5–6 people', '7+ people'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => _householdSize = v ?? _householdSize)),
      ],
      const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _busy || (_mode == 'Freshness' && widget.items.isEmpty) ? null : _ask, icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.auto_awesome), label: Text(_busy ? 'Thinking…' : _mode == 'Recipes' ? 'Suggest recipes' : _mode == 'Freshness' ? 'Get inspection guidance' : 'Create 3-day plan'), style: FilledButton.styleFrom(backgroundColor: forest, padding: const EdgeInsets.symmetric(vertical: 15)))),
      if (_error != null) ...[const SizedBox(height: 16), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFFFF0E9), borderRadius: BorderRadius.circular(15)), child: Text(_error!, style: const TextStyle(color: Color(0xFF8B3D27))))],
      if (_answer != null) ...[const SizedBox(height: 20), Row(children: [const Icon(Icons.auto_awesome, color: forest), const SizedBox(width: 8), Text('Gemini response', style: Theme.of(context).textTheme.titleLarge)]), const SizedBox(height: 10), Container(width: double.infinity, padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE5EAE3))), child: SelectableText(_answer!, style: const TextStyle(color: ink, height: 1.5, fontSize: 14)))],
      const SizedBox(height: 20), const Text('AI responses can be incomplete. For food safety, inspect the produce directly and follow reliable food-safety guidance.', style: TextStyle(color: muted, fontSize: 12)),
    ]));
  }
}
