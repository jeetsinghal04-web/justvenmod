import 'package:flutter_test/flutter_test.dart';
import 'package:sabzisaathi/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('vegetable catalog contains common Indian vegetables and aliases', () {
    expect(vegetables.any((v) => v.name == 'Potato' && v.hindi == 'Aloo'), isTrue);
    expect(vegetables.length, greaterThanOrEqualTo(45));
  });
}
