# SabziSaathi

Offline-first Flutter app for Indian household vegetable inventory, with optional Gemini kitchen assistance.

## Features
- SQLite inventory stored locally on the phone
- Searchable Indian vegetable catalog with Hindi names
- Add, view and remove vegetables
- Gemini AI: inventory-based Indian recipe suggestions, user-observation-based produce inspection guidance, and three-day meal planning with shopping list
- AI is optional; local inventory remains usable offline
- Material 3 forest-green and warm-cream interface

## Open in Android Studio
Open this folder (the one containing `pubspec.yaml`), then run:

```bash
flutter pub get
flutter run
```

## Build release APK with Gemini

```bash
flutter build apk --release --dart-define=GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

Optional model override: `--dart-define=GEMINI_MODEL=gemini-2.5-flash`

APK output: `build/app/outputs/flutter-apk/app-release.apk`

Without the key, local inventory works but AI requests show a configuration message. GitHub Actions can receive the key through the `GEMINI_API_KEY` repository secret.

## Security
A key passed with `--dart-define` is compiled into the APK and can be extracted. This is for private/personal testing only if you accept that risk. For public distribution, use a backend to keep the key server-side with authentication and rate limits. Rotate any key pasted into chats or committed to source control.

## Food-safety limitation
Gemini provides inspection guidance, not food-safety certification. The feature does not use image recognition, sensors, or laboratory testing and does not assign a guaranteed expiry date. Inspect produce directly and discard food with mould, slime, leaking or unusual odour, or when safety is uncertain.
